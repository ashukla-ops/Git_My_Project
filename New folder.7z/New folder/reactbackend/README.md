//Steps for starting the backend application.

Step:1 Install JAVA 1.8.
Step:2 Install maven.
Step:3 Set environment for maven and java.
step:4 download the sts or eclips.
step:5 clone the projects.
step:6 import the projects in sts.
step:7 install my sql with usetr root and password "";
step:8 start the mysql database.
step:9 run the application.