package com.org.java.rest.service;

public interface StockService {

}
