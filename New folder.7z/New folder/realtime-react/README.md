## React in realtime
step:1 Install node.js
step:2 Download VS code editor.
step:3 clone project from git into local folder.
step:4 Open in VS code.
Step:5 Open terminal using CTR+~  key.
step:6 run npm install from terminal.
step:7 run npm start.



