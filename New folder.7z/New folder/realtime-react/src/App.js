// App.js
import React, { Component } from 'react';
import _ from 'lodash';
import logo from './logo.svg';
import './App.css';
import Trade from './Autotrader';
import Tickers from './Tickers';
//import { restdb, realtimeURL } from './helper.js';


class App extends Component {
  componentDidMount() {
    // start trading
  }
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>React &amp; RestDB.io in Realtime</h2>
        </div>
        
        <h2>Real-time stock price trading</h2>
        <Trade/>
        <Tickers/>
      </div>
    );
  }
}

export default App;
